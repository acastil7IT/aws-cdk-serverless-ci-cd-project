"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
const cdk = __importStar(require("aws-cdk-lib"));
const assertions_1 = require("aws-cdk-lib/assertions");
const pipeline_stack_1 = require("../lib/pipeline-stack");
/**
 * Basic infrastructure tests for the Pipeline Stack
 *
 * These tests ensure that our CDK code synthesizes correctly
 * and creates the expected AWS resources.
 */
describe('PipelineStack', () => {
    let app;
    let stack;
    let template;
    beforeEach(() => {
        app = new cdk.App();
        stack = new pipeline_stack_1.PipelineStack(app, 'TestPipelineStack');
        template = assertions_1.Template.fromStack(stack);
    });
    test('Creates CodePipeline', () => {
        // Verify that a CodePipeline is created
        template.hasResourceProperties('AWS::CodePipeline::Pipeline', {
            Name: 'devops-portfolio-pipeline',
        });
    });
    test('Creates CodeBuild Project', () => {
        // Verify that a CodeBuild project is created
        template.hasResourceProperties('AWS::CodeBuild::Project', {
            Name: 'devops-portfolio-build',
        });
    });
    test('Creates S3 Bucket for Artifacts', () => {
        // Verify that an S3 bucket for artifacts is created
        template.hasResourceProperties('AWS::S3::Bucket', {
            BucketEncryption: {
                ServerSideEncryptionConfiguration: [
                    {
                        ServerSideEncryptionByDefault: {
                            SSEAlgorithm: 'AES256',
                        },
                    },
                ],
            },
        });
    });
    test('Pipeline has correct number of stages', () => {
        // Verify pipeline structure
        template.hasResourceProperties('AWS::CodePipeline::Pipeline', {
            Stages: [
                { Name: 'Source' },
                { Name: 'Build' },
                { Name: 'DeployDev' },
                { Name: 'ApprovalForProd' },
                { Name: 'DeployProd' },
            ],
        });
    });
    test('Stack has required tags', () => {
        // Verify that proper tags are applied
        const stackTags = cdk.Tags.of(stack);
        expect(stackTags).toBeDefined();
    });
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGlwZWxpbmUtc3RhY2sudGVzdC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbInBpcGVsaW5lLXN0YWNrLnRlc3QudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxpREFBbUM7QUFDbkMsdURBQWtEO0FBQ2xELDBEQUFzRDtBQUV0RDs7Ozs7R0FLRztBQUVILFFBQVEsQ0FBQyxlQUFlLEVBQUUsR0FBRyxFQUFFO0lBQzdCLElBQUksR0FBWSxDQUFDO0lBQ2pCLElBQUksS0FBb0IsQ0FBQztJQUN6QixJQUFJLFFBQWtCLENBQUM7SUFFdkIsVUFBVSxDQUFDLEdBQUcsRUFBRTtRQUNkLEdBQUcsR0FBRyxJQUFJLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQztRQUNwQixLQUFLLEdBQUcsSUFBSSw4QkFBYSxDQUFDLEdBQUcsRUFBRSxtQkFBbUIsQ0FBQyxDQUFDO1FBQ3BELFFBQVEsR0FBRyxxQkFBUSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUN2QyxDQUFDLENBQUMsQ0FBQztJQUVILElBQUksQ0FBQyxzQkFBc0IsRUFBRSxHQUFHLEVBQUU7UUFDaEMsd0NBQXdDO1FBQ3hDLFFBQVEsQ0FBQyxxQkFBcUIsQ0FBQyw2QkFBNkIsRUFBRTtZQUM1RCxJQUFJLEVBQUUsMkJBQTJCO1NBQ2xDLENBQUMsQ0FBQztJQUNMLENBQUMsQ0FBQyxDQUFDO0lBRUgsSUFBSSxDQUFDLDJCQUEyQixFQUFFLEdBQUcsRUFBRTtRQUNyQyw2Q0FBNkM7UUFDN0MsUUFBUSxDQUFDLHFCQUFxQixDQUFDLHlCQUF5QixFQUFFO1lBQ3hELElBQUksRUFBRSx3QkFBd0I7U0FDL0IsQ0FBQyxDQUFDO0lBQ0wsQ0FBQyxDQUFDLENBQUM7SUFFSCxJQUFJLENBQUMsaUNBQWlDLEVBQUUsR0FBRyxFQUFFO1FBQzNDLG9EQUFvRDtRQUNwRCxRQUFRLENBQUMscUJBQXFCLENBQUMsaUJBQWlCLEVBQUU7WUFDaEQsZ0JBQWdCLEVBQUU7Z0JBQ2hCLGlDQUFpQyxFQUFFO29CQUNqQzt3QkFDRSw2QkFBNkIsRUFBRTs0QkFDN0IsWUFBWSxFQUFFLFFBQVE7eUJBQ3ZCO3FCQUNGO2lCQUNGO2FBQ0Y7U0FDRixDQUFDLENBQUM7SUFDTCxDQUFDLENBQUMsQ0FBQztJQUVILElBQUksQ0FBQyx1Q0FBdUMsRUFBRSxHQUFHLEVBQUU7UUFDakQsNEJBQTRCO1FBQzVCLFFBQVEsQ0FBQyxxQkFBcUIsQ0FBQyw2QkFBNkIsRUFBRTtZQUM1RCxNQUFNLEVBQUU7Z0JBQ04sRUFBRSxJQUFJLEVBQUUsUUFBUSxFQUFFO2dCQUNsQixFQUFFLElBQUksRUFBRSxPQUFPLEVBQUU7Z0JBQ2pCLEVBQUUsSUFBSSxFQUFFLFdBQVcsRUFBRTtnQkFDckIsRUFBRSxJQUFJLEVBQUUsaUJBQWlCLEVBQUU7Z0JBQzNCLEVBQUUsSUFBSSxFQUFFLFlBQVksRUFBRTthQUN2QjtTQUNGLENBQUMsQ0FBQztJQUNMLENBQUMsQ0FBQyxDQUFDO0lBRUgsSUFBSSxDQUFDLHlCQUF5QixFQUFFLEdBQUcsRUFBRTtRQUNuQyxzQ0FBc0M7UUFDdEMsTUFBTSxTQUFTLEdBQUcsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDckMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDO0lBQ2xDLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgKiBhcyBjZGsgZnJvbSAnYXdzLWNkay1saWInO1xuaW1wb3J0IHsgVGVtcGxhdGUgfSBmcm9tICdhd3MtY2RrLWxpYi9hc3NlcnRpb25zJztcbmltcG9ydCB7IFBpcGVsaW5lU3RhY2sgfSBmcm9tICcuLi9saWIvcGlwZWxpbmUtc3RhY2snO1xuXG4vKipcbiAqIEJhc2ljIGluZnJhc3RydWN0dXJlIHRlc3RzIGZvciB0aGUgUGlwZWxpbmUgU3RhY2tcbiAqIFxuICogVGhlc2UgdGVzdHMgZW5zdXJlIHRoYXQgb3VyIENESyBjb2RlIHN5bnRoZXNpemVzIGNvcnJlY3RseVxuICogYW5kIGNyZWF0ZXMgdGhlIGV4cGVjdGVkIEFXUyByZXNvdXJjZXMuXG4gKi9cblxuZGVzY3JpYmUoJ1BpcGVsaW5lU3RhY2snLCAoKSA9PiB7XG4gIGxldCBhcHA6IGNkay5BcHA7XG4gIGxldCBzdGFjazogUGlwZWxpbmVTdGFjaztcbiAgbGV0IHRlbXBsYXRlOiBUZW1wbGF0ZTtcblxuICBiZWZvcmVFYWNoKCgpID0+IHtcbiAgICBhcHAgPSBuZXcgY2RrLkFwcCgpO1xuICAgIHN0YWNrID0gbmV3IFBpcGVsaW5lU3RhY2soYXBwLCAnVGVzdFBpcGVsaW5lU3RhY2snKTtcbiAgICB0ZW1wbGF0ZSA9IFRlbXBsYXRlLmZyb21TdGFjayhzdGFjayk7XG4gIH0pO1xuXG4gIHRlc3QoJ0NyZWF0ZXMgQ29kZVBpcGVsaW5lJywgKCkgPT4ge1xuICAgIC8vIFZlcmlmeSB0aGF0IGEgQ29kZVBpcGVsaW5lIGlzIGNyZWF0ZWRcbiAgICB0ZW1wbGF0ZS5oYXNSZXNvdXJjZVByb3BlcnRpZXMoJ0FXUzo6Q29kZVBpcGVsaW5lOjpQaXBlbGluZScsIHtcbiAgICAgIE5hbWU6ICdkZXZvcHMtcG9ydGZvbGlvLXBpcGVsaW5lJyxcbiAgICB9KTtcbiAgfSk7XG5cbiAgdGVzdCgnQ3JlYXRlcyBDb2RlQnVpbGQgUHJvamVjdCcsICgpID0+IHtcbiAgICAvLyBWZXJpZnkgdGhhdCBhIENvZGVCdWlsZCBwcm9qZWN0IGlzIGNyZWF0ZWRcbiAgICB0ZW1wbGF0ZS5oYXNSZXNvdXJjZVByb3BlcnRpZXMoJ0FXUzo6Q29kZUJ1aWxkOjpQcm9qZWN0Jywge1xuICAgICAgTmFtZTogJ2Rldm9wcy1wb3J0Zm9saW8tYnVpbGQnLFxuICAgIH0pO1xuICB9KTtcblxuICB0ZXN0KCdDcmVhdGVzIFMzIEJ1Y2tldCBmb3IgQXJ0aWZhY3RzJywgKCkgPT4ge1xuICAgIC8vIFZlcmlmeSB0aGF0IGFuIFMzIGJ1Y2tldCBmb3IgYXJ0aWZhY3RzIGlzIGNyZWF0ZWRcbiAgICB0ZW1wbGF0ZS5oYXNSZXNvdXJjZVByb3BlcnRpZXMoJ0FXUzo6UzM6OkJ1Y2tldCcsIHtcbiAgICAgIEJ1Y2tldEVuY3J5cHRpb246IHtcbiAgICAgICAgU2VydmVyU2lkZUVuY3J5cHRpb25Db25maWd1cmF0aW9uOiBbXG4gICAgICAgICAge1xuICAgICAgICAgICAgU2VydmVyU2lkZUVuY3J5cHRpb25CeURlZmF1bHQ6IHtcbiAgICAgICAgICAgICAgU1NFQWxnb3JpdGhtOiAnQUVTMjU2JyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICAgIH0sXG4gICAgfSk7XG4gIH0pO1xuXG4gIHRlc3QoJ1BpcGVsaW5lIGhhcyBjb3JyZWN0IG51bWJlciBvZiBzdGFnZXMnLCAoKSA9PiB7XG4gICAgLy8gVmVyaWZ5IHBpcGVsaW5lIHN0cnVjdHVyZVxuICAgIHRlbXBsYXRlLmhhc1Jlc291cmNlUHJvcGVydGllcygnQVdTOjpDb2RlUGlwZWxpbmU6OlBpcGVsaW5lJywge1xuICAgICAgU3RhZ2VzOiBbXG4gICAgICAgIHsgTmFtZTogJ1NvdXJjZScgfSxcbiAgICAgICAgeyBOYW1lOiAnQnVpbGQnIH0sXG4gICAgICAgIHsgTmFtZTogJ0RlcGxveURldicgfSxcbiAgICAgICAgeyBOYW1lOiAnQXBwcm92YWxGb3JQcm9kJyB9LFxuICAgICAgICB7IE5hbWU6ICdEZXBsb3lQcm9kJyB9LFxuICAgICAgXSxcbiAgICB9KTtcbiAgfSk7XG5cbiAgdGVzdCgnU3RhY2sgaGFzIHJlcXVpcmVkIHRhZ3MnLCAoKSA9PiB7XG4gICAgLy8gVmVyaWZ5IHRoYXQgcHJvcGVyIHRhZ3MgYXJlIGFwcGxpZWRcbiAgICBjb25zdCBzdGFja1RhZ3MgPSBjZGsuVGFncy5vZihzdGFjayk7XG4gICAgZXhwZWN0KHN0YWNrVGFncykudG9CZURlZmluZWQoKTtcbiAgfSk7XG59KTsiXX0=