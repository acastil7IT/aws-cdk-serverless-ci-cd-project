import * as cdk from 'aws-cdk-lib';
import * as s3 from 'aws-cdk-lib/aws-s3';
import { Construct } from 'constructs';
/**
 * Frontend Stack - S3 Static Website + CloudFront CDN
 *
 * This stack creates:
 * - S3 bucket for static website hosting
 * - CloudFront distribution for global CDN
 * - Automatic deployment of frontend assets
 * - Security headers and HTTPS enforcement
 *
 * Demonstrates enterprise patterns:
 * - Global content delivery with CloudFront
 * - Security best practices (HTTPS, security headers)
 * - Cost optimization (S3 + CloudFront vs EC2)
 * - Automated asset deployment
 */
export interface FrontendStackProps extends cdk.StackProps {
    /** Environment name (dev, prod, etc.) */
    stageName: string;
    /** API Gateway URL to configure in frontend */
    apiUrl: string;
    /** Custom domain name (optional) */
    domainName?: string;
}
export declare class FrontendStack extends cdk.Stack {
    /** CloudFront distribution URL */
    readonly distributionUrl: string;
    /** S3 bucket for static assets */
    readonly websiteBucket: s3.Bucket;
    constructor(scope: Construct, id: string, props: FrontendStackProps);
}
