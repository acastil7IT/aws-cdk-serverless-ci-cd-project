import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
/**
 * Application Stage Definition
 *
 * This class defines a complete application stage (Dev or Prod).
 * Each stage contains all the infrastructure needed for a complete
 * environment: API Gateway + Lambda + S3 + CloudFront.
 *
 * This pattern allows us to deploy identical infrastructure
 * to multiple environments with different configurations.
 */
export interface ApplicationStageProps extends cdk.StageProps {
    /** Environment name (dev, prod, etc.) */
    stageName: string;
    /** Domain name for the frontend (optional) */
    domainName?: string;
    /** Whether to enable detailed monitoring */
    enableDetailedMonitoring?: boolean;
}
export declare class ApplicationStage extends cdk.Stage {
    /** API Gateway URL for this stage */
    readonly apiUrl: string;
    /** CloudFront distribution URL for this stage */
    readonly frontendUrl: string;
    constructor(scope: Construct, id: string, props: ApplicationStageProps);
}
