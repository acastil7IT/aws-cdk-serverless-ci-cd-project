import * as cdk from 'aws-cdk-lib';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import * as dynamodb from 'aws-cdk-lib/aws-dynamodb';
import { Construct } from 'constructs';
/**
 * API Stack - Lambda Functions + API Gateway
 *
 * This stack creates:
 * - Lambda function with our application code
 * - API Gateway REST API with proper CORS configuration
 * - CloudWatch log groups for monitoring
 * - IAM roles with least-privilege access
 *
 * Demonstrates enterprise patterns:
 * - Proper error handling and logging
 * - Security best practices (CORS, throttling)
 * - Cost optimization (ARM64, appropriate memory sizing)
 */
export interface ApiStackProps extends cdk.StackProps {
    /** Environment name (dev, prod, etc.) */
    stageName: string;
    /** Whether to enable detailed monitoring and X-Ray tracing */
    enableDetailedMonitoring?: boolean;
}
export declare class ApiStack extends cdk.Stack {
    /** API Gateway URL */
    readonly apiUrl: string;
    /** Lambda function for external reference */
    readonly lambdaFunction: lambda.Function;
    /** DynamoDB table for data storage */
    readonly dataTable: dynamodb.Table;
    constructor(scope: Construct, id: string, props: ApiStackProps);
}
