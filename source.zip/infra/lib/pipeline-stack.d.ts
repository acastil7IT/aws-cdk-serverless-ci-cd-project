import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
/**
 * CI/CD Pipeline Stack using AWS CodePipeline
 *
 * This stack creates a complete CI/CD pipeline that:
 * 1. Sources code from GitHub/CodeStar
 * 2. Builds and tests the application
 * 3. Deploys to Dev environment automatically
 * 4. Waits for manual approval
 * 5. Deploys to Prod environment
 *
 * Demonstrates enterprise CI/CD patterns:
 * - Multi-environment deployment strategy
 * - Manual approval gates for production
 * - Automated testing and validation
 * - Infrastructure as Code deployment
 * - Proper IAM roles and permissions
 */
export interface PipelineStackProps extends cdk.StackProps {
    /** GitHub repository owner (optional, defaults to manual source) */
    githubOwner?: string;
    /** GitHub repository name (optional, defaults to manual source) */
    githubRepo?: string;
    /** GitHub branch to track (defaults to main) */
    githubBranch?: string;
}
export declare class PipelineStack extends cdk.Stack {
    constructor(scope: Construct, id: string, props?: PipelineStackProps);
}
